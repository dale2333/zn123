package com.wut.zn;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZnApplicationTests {

    @Test
    void contextLoads() {
    }

}
