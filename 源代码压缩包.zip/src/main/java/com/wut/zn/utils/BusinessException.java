package com.wut.zn.utils;

public class BusinessException extends RuntimeException {
    public BusinessException(String message) {
        super(message);
    }
}